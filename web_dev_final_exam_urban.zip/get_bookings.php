<?php

  $sBookings = file_get_contents("bookings.json");
  echo $sBookings;

?>
