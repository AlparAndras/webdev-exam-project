<?php

  $sTables = file_get_contents("tables.json");
  echo $sTables;

?>
