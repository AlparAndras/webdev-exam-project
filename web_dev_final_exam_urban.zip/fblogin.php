<?php

  // session_start();
  //
  // require_once 'vendor/autoload.php';
  // use Facebook\FacebookSession;
  //
  // FacebookSession::setDefaultApplication('1615857338710945','509bc34ba88af568f5a83356ced99fda');
  // $facebook = new Facebook\FacebookRedirectLoginHelper('http://localhost/Reservation/index.php');


  // session_start();
  //
  // require_once '/vendor/autoload.php';
  //
  // $fb = new Facebook\Facebook([
  //   'app_id' => '1615857338710945',
	//   'app_secret' => '509bc34ba88af568f5a83356ced99fda',
	//   'default_graph_version' => 'v2.5',
  // ]);
  //
  // $redirect = 'http://localhost/Reservation/index.php';
  //
  // $helper = $fb->getRedirectLoginHelper();
  //
  // try {
	//   $accessToken = $helper->getAccessToken();
	// } catch(Facebook\Exceptions\FacebookResponseException $e) {
	//
	//   echo 'Graph returned an error: ' . $e->getMessage();
	//   exit;
	// } catch(Facebook\Exceptions\FacebookSDKException $e) {
	//   echo 'Facebook SDK returned an error: ' . $e->getMessage();
	//   exit;
	// }
  //
  // if (isset($accessToken)) {
	// 	$fb->setDefaultAccessToken($accessToken);
	// 	try {
	// 	  $response = $fb->get('/me?fields=email,name');
	// 	  $userNode = $response->getGraphUser();
	// 	}catch(Facebook\Exceptions\FacebookResponseException $e) {
	// 	  echo 'Graph returned an error: ' . $e->getMessage();
	// 	  exit;
	// 	} catch(Facebook\Exceptions\FacebookSDKException $e) {
	// 	  echo 'Facebook SDK returned an error: ' . $e->getMessage();
	// 	  exit;
	// 	}
	// 	echo "Welcome !<br><br>";
	// 	echo 'Name: ' . $userNode->getName().'<br>';
	// 	echo 'User ID: ' . $userNode->getId().'<br>';
	// 	echo 'Email: ' . $userNode->getProperty('email').'<br><br>';
	// 	$image = 'https://graph.facebook.com/'.$userNode->getId().'/picture?width=200';
	// 	echo "Picture<br>";
	// 	echo "<img src='$image' /><br><br>";
  //
	// }else{
	// 	$permissions  = ['email'];
	// 	$loginUrl = $helper->getLoginUrl($redirect,$permissions);
	// 	echo '<a href="' . $loginUrl . '">Log in with Facebook!</a>';
	// }


?>
